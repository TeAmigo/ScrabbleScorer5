package com.rick.scrabblescorer5;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

public class ListGameActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridview_gamelayout);
        GridView lgame = findViewById(R.id.list_game_gridview);
        DatabaseHelper dbh = new DatabaseHelper(this, DatabaseHelper.DATABASE_NAME,
                null, DatabaseHelper.DATABASE_VERSION);
        SQLiteDatabase db = dbh.getWritableDatabase();
        //   String queryCurrentGame = "select id as _id, player from GamePlay";
        String queryCurrentGame = "select id as _id, playnumber, player, points from GamePlay where gameid = " +
                String.valueOf(dbh.getCurrentGameTopId()) + " order by playnumber";
        Cursor cur = db.rawQuery(queryCurrentGame, null);
        int ct = cur.getColumnCount();
        int cnt = cur.getCount();
        ListGameAdapter lga = new ListGameAdapter(this, null);
        lga.changeCursor(cur);
        lgame.setAdapter(lga);
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//        getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

